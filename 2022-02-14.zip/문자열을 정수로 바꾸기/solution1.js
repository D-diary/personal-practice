// https://programmers.co.kr/learn/courses/30/lessons/12925

function solution(s) {
  let answer = 0;

  answer = Number(s);

  return answer;
}

console.log(solution("1234")); // 1234
console.log(solution("-1234")); // -1234