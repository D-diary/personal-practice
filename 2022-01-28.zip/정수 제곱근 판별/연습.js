// let i = 0;
// while(i<500){
//   i++;
//   console.log(i)
// }

function solution(n) {
  let x = 0;
  
  while ( n < 200 ) {
    x++;
    console.log(x)
  }
}

console.log(solution(121))